package com.itheima.hibernate.utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
/**
 * ������
 * @author Administrator
 *
 */
public abstract class HibernateUtils {
	protected static SessionFactory sessionFactory;
	protected static Session session;
	protected Transaction transaction;
	
	static
	{
		Configuration configuration = new Configuration();
		configuration.configure();
		sessionFactory = configuration.buildSessionFactory();
		session=sessionFactory.openSession();
	}
	/**
	 * ִ�к��������HQL��䡣
	 * @param hql
	 */
	public void excude(HQLHandler hql)
	{
		 transaction=session.beginTransaction();
		 hql.HQL();
		 transaction.commit();
		 session.close();
	}
	/**
	 * ִ�в����������HQL��䡣
	 * @param hql
	 */
	public void excudeQuery( HQLHandler hql)
	{
		hql.HQL();
		session.close();
	}
}


